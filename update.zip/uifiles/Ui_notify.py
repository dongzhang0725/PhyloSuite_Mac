# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'notify.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

